package com.lykos.pointage.model.data

class LoginData(
    val username: String,
    val password: String
)