package com.lykos.pointage.model.data

data class PvReportData(
    val id: String,
    val userId: String,
    val note: String?
)