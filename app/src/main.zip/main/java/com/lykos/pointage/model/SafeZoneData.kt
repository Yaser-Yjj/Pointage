package com.lykos.pointage.model

data class SafeZoneData(
    val latitude: Double,
    val longitude: Double,
    val radius: Float
)