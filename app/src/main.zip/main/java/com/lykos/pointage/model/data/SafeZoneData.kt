package com.lykos.pointage.model.data

data class SafeZoneData(
    val latitude: Double,
    val longitude: Double,
    val radius: Float
)